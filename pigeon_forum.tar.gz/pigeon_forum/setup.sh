#!/usr/bin/env bash
# Setup script for Pigeon Watchers Anonymous forum
# Usage: ./setup.sh [install_dir]

set -e

INSTALL_DIR="${1:-$HOME/pigeon_forum}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Installing Pigeon Watchers Anonymous to $INSTALL_DIR"

mkdir -p "$INSTALL_DIR"
cp -r "$SCRIPT_DIR"/* "$INSTALL_DIR"/

cd "$INSTALL_DIR"

echo "==> Creating Python virtual environment"
python3 -m venv venv
source venv/bin/activate

echo "==> Installing dependencies"
pip install --upgrade pip
pip install -r requirements.txt

echo "==> Generating a random secret key"
SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
echo "export SECRET_KEY=\"$SECRET_KEY\"" > "$INSTALL_DIR/.env"

echo "==> Initializing database"
python3 -c "from app import init_db; init_db()"

echo ""
echo "==> Setup complete."
echo "To run the forum:"
echo "  cd $INSTALL_DIR"
echo "  source venv/bin/activate"
echo "  source .env"
echo "  python3 app.py"
echo ""
echo "The forum listens on 127.0.0.1:5000 only. Put it behind a reverse proxy"
echo "or restrict access at the firewall if you need it reachable elsewhere."
