# Pigeon Watchers Anonymous

A tiny Flask + SQLite forum for reporting pigeon sightings. Built for CSDA Lab 4,
Part 2.5 ("vibe coding").

## Features
- Account creation (`/register`) with hashed passwords (Werkzeug `generate_password_hash`)
- Login/logout with server-side sessions (`/login`, `/logout`)
- Image upload attached to a post, restricted to png/jpg/jpeg/gif, 5 MB max
- Text postings visible to all visitors, newest first (`/`, `/new`)

## Install

```
tar xzf pigeon_forum.tar.gz
cd pigeon_forum
chmod +x setup.sh
./setup.sh
```

This creates a virtual environment, installs dependencies, generates a random
`SECRET_KEY`, and initializes the SQLite database.

## Run

```
cd ~/pigeon_forum        # or wherever you installed it
source venv/bin/activate
source .env
python3 app.py
```

The app binds to `127.0.0.1:5000` only — it is not exposed externally by
default. Put it behind a reverse proxy (nginx) or restrict access at the
firewall/security-group level for anything beyond local testing.

## Known limitations (intentional, for the security-assessment exercise)

- No CSRF tokens on forms
- No rate limiting on login/register (brute-force possible)
- No email verification
- No admin role / moderation panel
- Uploaded filenames are timestamp-prefixed but not re-encoded, so a
  crafted image with embedded PHP would still just be stored as a static
  file — Flask's static file server does not execute it, but this is
  worth verifying explicitly during testing
